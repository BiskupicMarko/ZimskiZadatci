 <!-- Početak podnožja -->
 <div class="grid-x">
    <div class="large-12 small-12 columns">
    <div class="<?php echo $dev ? 'alert' : 'warning'; ?> callout"> 
    &copy; <?php echo $nazivAPP; ?> 2019
    </div>
</div>
</div>
<!-- Kraj podnožja -->